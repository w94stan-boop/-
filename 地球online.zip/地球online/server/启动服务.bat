@echo off
chcp 65001 >nul
echo ========================================
echo   星轨共鸣 · 后端服务启动
echo ========================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [错误] 未检测到 Node.js
    echo.
    echo 请先安装 Node.js:
    echo   下载地址: https://nodejs.org/
    echo   安装后重新运行此脚本
    echo.
    pause
    exit /b 1
)

echo [1/3] 检查依赖...
if not exist "node_modules" (
    echo [2/3] 正在安装依赖...
    call npm install
) else (
    echo [2/3] 依赖已安装
)

echo [3/3] 启动服务...
echo.
echo ========================================
echo   服务启动成功！
echo   首页: http://localhost:3000/index.html
echo   按 Ctrl+C 停止服务
echo ========================================
echo.

node server.js

pause

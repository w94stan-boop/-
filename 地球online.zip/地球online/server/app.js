const express = require('express');
const cors = require('cors');
const https = require('https');
const http = require('http');
const { v4: uuidv4 } = require('uuid');

const app = express();

app.use(cors());
app.use(express.json());

const db = {
  users: new Map(),
  letters: new Map(),
  onlineUsers: new Set()
};

const emotionLexicon = {
  joy: ['快乐', '开心', '高兴', '幸福', '满足', '喜悦', '愉快', '兴奋', '欣喜', '欢乐', '美好', '感恩', '满意', '畅快', '轻松', '喜欢', '爱'],
  sadness: ['难过', '伤心', '悲伤', '失落', '沮丧', '痛苦', '心碎', '哭', '眼泪', '孤独', '寂寞', '忧伤', '哀愁', '心酸', '低落', '沉重', '绝望'],
  anger: ['愤怒', '生气', '烦躁', '暴躁', '恼火', '气愤', '怨恨', '讨厌', '憎恨', '不爽', '抓狂', '不满', '气', '恼火'],
  fear: ['害怕', '恐惧', '担忧', '焦虑', '不安', '紧张', '担心', '恐慌', '畏惧', '怕', '忐忑', '惶恐', '忧虑', '焦急', '失眠', '压力'],
  surprise: ['惊讶', '意外', '没想到', '震惊', '吃惊', '突然', '惊喜', '诧异', '惊奇', '出乎意料', '哇塞', '天哪'],
  calm: ['平静', '宁静', '安心', '淡定', '平和', '安宁', '恬静', '静谧', '安稳', '沉着', '冷静', '从容', '放松', '舒适', '悠闲', '自在']
};

const topicLexicon = {
  '工作事业': ['工作', '公司', '老板', '同事', '加班', '职场', '项目', '任务', '业绩', '晋升', '辞职', '面试', 'offer', '压力', '摸鱼', '上班', '下班', '工资'],
  '情感关系': ['喜欢', '爱', '恋爱', '分手', '前任', '男朋友', '女朋友', '爱情', '暗恋', '表白', '异地', '吵架', '和好', '思念', '想念', '孤独', '陪伴', '心碎'],
  '家庭生活': ['家人', '父母', '爸爸', '妈妈', '孩子', '家庭', '回家', '爸妈', '亲人', '兄弟姐妹', '家务', '做饭', '生活', '日常', '温暖', '争吵', '代沟'],
  '学业考试': ['学习', '考试', '考研', '高考', '作业', '论文', '毕业', '学校', '大学', '高中', '成绩', '挂科', '复习', '备考', '读书', '学生', '上课'],
  '健康养生': ['身体', '生病', '医院', '医生', '健康', '运动', '减肥', '失眠', '疲惫', '累', '养生', '健身', '跑步', '瑜伽', '饮食', '作息', '疲劳', '调理'],
  '兴趣爱好': ['电影', '音乐', '游戏', '看书', '旅行', '摄影', '画画', '做饭', '手工', '宠物', '猫', '狗', '追剧', '小说', '动漫', '爬山', '骑行', '咖啡'],
  '经济财务': ['钱', '工资', '房租', '房贷', '花钱', '省钱', '理财', '投资', '股票', '基金', '贫穷', '富裕', '消费', '奖金', '欠债', '还款'],
  '人生思考': ['人生', '意义', '迷茫', '未来', '梦想', '目标', '选择', '方向', '困惑', '活着', '存在', '理想', '现实', '成长', '改变', '自我', '思考']
};

const stopWords = ['的', '了', '是', '在', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这', '那', '他', '她', '它', '们', '这个', '那个', '什么', '怎么', '为什么', '可以', '还是', '但是', '因为', '所以', '如果', '虽然', '然后', '现在', '今天', '昨天', '明天', '觉得', '感觉', '真的', '其实', '非常', '特别', '比较', '这样', '那样'];

const userPersonas = [
  { id: 1, name: '极光守望者', avatar: '🌌', location: '冰岛 · 雷克雅未克', lifestyle: '独居', pace: '慢节奏', traits: ['内向', '敏感', '理想主义'], diary: '今夜的雷克雅未克没有极光，但海浪拍打礁石的声音比任何光都更清晰。我在灯塔里守望着这片黑色的海，想起你写下的文字。其实星辰一直在那里，只是云层太厚。当你愿意抬头时，它们会为你闪烁。', tasks: ['像灯塔守望者一样静坐5分钟', '走到窗边观察天空的颜色变化', '写下一件今天让你微笑的小事'], emotionProfile: { joy: 0.4, sadness: 0.5, anger: 0.1, fear: 0.3, surprise: 0.4, calm: 0.8 }, topics: ['人生思考', '兴趣爱好', '健康养生'] },
  { id: 2, name: '雨巷旅人', avatar: '☔', location: '挪威 · 卑尔根', lifestyle: '独居', pace: '慢节奏', traits: ['感性', '怀旧', '有同理心'], diary: '卑尔根的雨已经下了三天，但我知道云层之上永远有阳光。雨雾中的木屋透出温暖的灯火，就像你心中未曾熄灭的希望。孤独其实并不可怕，它只是让你更清晰地听见自己内心的声音。', tasks: ['泡一杯热茶静静听雨', '给远方的朋友发一条问候', '写下三个你感谢的人'], emotionProfile: { joy: 0.3, sadness: 0.8, anger: 0.2, fear: 0.5, surprise: 0.2, calm: 0.5 }, topics: ['情感关系', '家庭生活', '人生思考'] },
  { id: 3, name: '山顶追风人', avatar: '🏔️', location: '新西兰 · 皇后镇', lifestyle: '游牧', pace: '中节奏', traits: ['自由', '冒险', '乐观'], diary: '站在皇后镇的山顶，脚下是瓦卡蒂普湖湛蓝的水面。远方的雪山在云雾中若隐若现，就像你未来的道路。迷茫是暂时的，就像晨雾终将散去。深呼吸，让大自然的力量指引你前行。', tasks: ['闭上眼睛做三次深呼吸', '列出三件你喜欢做的事', '给自己写一句鼓励的话'], emotionProfile: { joy: 0.8, sadness: 0.2, anger: 0.1, fear: 0.3, surprise: 0.6, calm: 0.6 }, topics: ['人生思考', '兴趣爱好', '工作事业'] },
  { id: 4, name: '枯山水僧侣', avatar: '🍵', location: '日本 · 京都', lifestyle: '规律', pace: '慢节奏', traits: ['沉稳', '内敛', '有耐心'], diary: '枯山水庭院里的白砂如水般流动，青苔在石头上静静生长。在京都的古寺中，时间仿佛放慢了脚步。你不需要一直奔跑，停下来休息并不是放弃。让身心回归平静，才能重新出发。', tasks: ['找一处安静的角落闭目养神', '听一首舒缓的音乐', '泡个热水澡放松身心'], emotionProfile: { joy: 0.5, sadness: 0.2, anger: 0.1, fear: 0.2, surprise: 0.1, calm: 0.95 }, topics: ['健康养生', '家庭生活', '人生思考'] },
  { id: 5, name: '雪峰净化者', avatar: '❄️', location: '瑞士 · 采尔马特', lifestyle: '运动', pace: '快节奏', traits: ['坚韧', '理性', '自律'], diary: '马特洪峰的冰雪在阳光下闪耀着蓝色的光芒，空气纯净得仿佛能洗去一切尘埃。愤怒是一团火，它会灼伤自己也伤害他人。深呼吸，想象自己站在雪山之巅，让清风带走所有的火气。', tasks: ['做10次深呼吸慢慢呼气', '去户外走一圈感受自然', '把烦恼写在纸上然后撕掉'], emotionProfile: { joy: 0.6, sadness: 0.1, anger: 0.7, fear: 0.3, surprise: 0.4, calm: 0.7 }, topics: ['健康养生', '工作事业', '经济财务'] },
  { id: 6, name: '巨石守望者', avatar: '🌅', location: '澳大利亚 · 乌鲁鲁', lifestyle: '游牧', pace: '慢节奏', traits: ['神秘', '有深度', '爱探索'], diary: '乌鲁鲁巨石在夕阳下变幻着颜色，从金色到橙红再到深紫。这片土地见证了亿万年的变迁，而你的烦恼只是时间长河中的一瞬。生命本就是一场旅程，每一个当下都有它独特的意义。', tasks: ['观察身边三件从未注意的事物', '尝试一种从未吃过的食物', '写下今天觉得有趣的一件事'], emotionProfile: { joy: 0.5, sadness: 0.4, anger: 0.2, fear: 0.3, surprise: 0.7, calm: 0.6 }, topics: ['人生思考', '兴趣爱好', '旅行探索'] },
  { id: 7, name: '沙漠观星人', avatar: '⭐', location: '智利 · 阿塔卡马', lifestyle: '独居', pace: '慢节奏', traits: ['孤独', '深刻', '有哲思'], diary: '阿塔卡马沙漠的星空是世界上最璀璨的，银河横跨天际，繁星触手可及。在这片无垠的宇宙面前，所有的痛苦都变得渺小。请相信，即使在最深的黑暗中，也总有星光为你指引方向。', tasks: ['晚上抬头看看星空', '回想一件让你感到希望的事', '告诉自己「明天会更好」'], emotionProfile: { joy: 0.3, sadness: 0.7, anger: 0.2, fear: 0.8, surprise: 0.5, calm: 0.4 }, topics: ['人生思考', '学业考试', '情感关系'] },
  { id: 8, name: '湖泊漫步者', avatar: '🏞️', location: '加拿大 · 班夫', lifestyle: '户外', pace: '中节奏', traits: ['活力', '阳光', '有冲劲'], diary: '班夫的湖泊倒映着雪山，森林在微风中低语。生命中的每一次挑战都是成长的机会，就像攀登高山需要勇气。相信自己的能力，你比想象中更强大。', tasks: ['列出三个你已经克服的困难', '告诉自己「我能行」', '做一些简单的伸展运动'], emotionProfile: { joy: 0.9, sadness: 0.1, anger: 0.3, fear: 0.4, surprise: 0.5, calm: 0.5 }, topics: ['工作事业', '健康养生', '兴趣爱好'] },
  { id: 9, name: '都市夜归人', avatar: '🌃', location: '中国 · 上海', lifestyle: '忙碌', pace: '快节奏', traits: ['努力', '上进', '有点累'], diary: '上海的霓虹亮了一整夜，写字楼的灯光像永不熄灭的星。我知道你也在这座城市里努力着，有时候会觉得累，有时候会迷茫。但请相信，每一个深夜的坚持，都在为你照亮未来的路。', tasks: ['给自己点一份喜欢的夜宵', '睡前放下手机冥想10分钟', '周末计划一次小小的逃离'], emotionProfile: { joy: 0.4, sadness: 0.6, anger: 0.4, fear: 0.7, surprise: 0.3, calm: 0.2 }, topics: ['工作事业', '经济财务', '人生思考'] },
  { id: 10, name: '山城少年', avatar: '🏘️', location: '中国 · 重庆', lifestyle: '热闹', pace: '中节奏', traits: ['直率', '热情', '爱吃辣'], diary: '重庆的轻轨又从楼里穿过去了，火锅的香气飘满了整条街。生活嘛，就像这山城的路，上上下下的，但总是有新的风景在等你。没得啥子坎是过不去的，整一碗小面，又是新的一天。', tasks: ['去吃一顿好吃的犒劳自己', '给家人打个电话唠唠嗑', '出门散散步看看烟火气'], emotionProfile: { joy: 0.7, sadness: 0.2, anger: 0.5, fear: 0.2, surprise: 0.5, calm: 0.4 }, topics: ['家庭生活', '工作事业', '兴趣爱好'] },
  { id: 11, name: '珊瑚岛居民', avatar: '🌴', location: '马尔代夫 · 马累', lifestyle: '度假', pace: '慢节奏', traits: ['温暖', '友善', '会享受'], diary: '马尔代夫的海水清澈见底，珊瑚在阳光下闪烁着五彩斑斓的光芒。感谢你愿意分享这份心情，让我也感受到了你的存在。请记住当下的感觉，让它成为你前进的动力。', tasks: ['写下今天让你开心的三件事', '给帮助过你的人发个感谢', '做一个深呼吸感受当下'], emotionProfile: { joy: 0.95, sadness: 0.05, anger: 0.05, fear: 0.1, surprise: 0.6, calm: 0.8 }, topics: ['兴趣爱好', '家庭生活', '健康养生'] },
  { id: 12, name: '恒河渡者', avatar: '🕉️', location: '印度 · 瓦拉纳西', lifestyle: '灵修', pace: '慢节奏', traits: ['宽容', '慈悲', '有智慧'], diary: '恒河的水流淌了千年，带走了无数人的悲伤与悔恨。在瓦拉纳西的晨曦中，一切都可以重新开始。过去的已经过去，重要的是现在和未来。原谅自己，才能真正放下。', tasks: ['写下一件让你释怀的事', '对自己说一声「没关系」', '做一件让自己开心的小事'], emotionProfile: { joy: 0.6, sadness: 0.6, anger: 0.2, fear: 0.5, surprise: 0.3, calm: 0.8 }, topics: ['人生思考', '健康养生', '情感关系'] }
];

function analyzeText(text) {
  const result = {
    emotions: { joy: 0, sadness: 0, anger: 0, fear: 0, surprise: 0, calm: 0 },
    keywords: [],
    topics: []
  };

  Object.keys(emotionLexicon).forEach(function(emotion) {
    let count = 0;
    emotionLexicon[emotion].forEach(function(word) {
      let idx = text.indexOf(word);
      while(idx !== -1) {
        count++;
        idx = text.indexOf(word, idx + 1);
      }
    });
    result.emotions[emotion] = count;
  });

  let maxEmotion = 0;
  Object.keys(result.emotions).forEach(function(e) {
    if(result.emotions[e] > maxEmotion) maxEmotion = result.emotions[e];
  });
  if(maxEmotion > 0) {
    Object.keys(result.emotions).forEach(function(e) {
      result.emotions[e] = Math.round((result.emotions[e] / maxEmotion) * 100);
    });
  }

  const wordCount = {};
  const sentences = text.split(/[。！？.!?\n]+/);
  sentences.forEach(function(sentence) {
    const chars = sentence.split('');
    for(let len = 2; len <= 4; len++) {
      for(let i = 0; i <= chars.length - len; i++) {
        const word = chars.slice(i, i + len).join('');
        if(stopWords.includes(word) || /\d/.test(word)) continue;
        wordCount[word] = (wordCount[word] || 0) + 1;
      }
    }
  });

  const sortedWords = Object.entries(wordCount)
    .filter(function(w) { return w[1] >= 1 && w[0].length >= 2; })
    .sort(function(a, b) { return b[1] - a[1]; })
    .slice(0, 8);

  result.keywords = sortedWords.map(function(w) { return w[0]; });

  const topicScores = {};
  Object.keys(topicLexicon).forEach(function(topic) {
    let score = 0;
    topicLexicon[topic].forEach(function(word) {
      if(text.includes(word)) score++;
    });
    if(score > 0) topicScores[topic] = score;
  });

  const sortedTopics = Object.entries(topicScores).sort(function(a, b) { return b[1] - a[1]; });
  result.topics = sortedTopics.slice(0, 3).map(function(t) { return t[0]; });

  return result;
}

function cosineSimilarity(vec1, vec2) {
  let dotProduct = 0;
  let mag1 = 0;
  let mag2 = 0;
  Object.keys(vec1).forEach(function(key) {
    dotProduct += (vec1[key] || 0) * (vec2[key] || 0);
    mag1 += (vec1[key] || 0) ** 2;
    mag2 += (vec2[key] || 0) ** 2;
  });
  mag1 = Math.sqrt(mag1);
  mag2 = Math.sqrt(mag2);
  if(mag1 === 0 || mag2 === 0) return 0;
  return dotProduct / (mag1 * mag2);
}

function matchPersona(analysisResult) {
  let bestMatch = null;
  let bestScore = -1;

  userPersonas.forEach(function(persona) {
    const userEmotionVec = analysisResult.emotions;
    const personaEmotionVec = {};
    Object.keys(persona.emotionProfile).forEach(function(e) {
      personaEmotionVec[e] = Math.round(persona.emotionProfile[e] * 100);
    });

    const emotionSim = cosineSimilarity(userEmotionVec, personaEmotionVec);

    let topicMatch = 0;
    if(analysisResult.topics.length > 0) {
      analysisResult.topics.forEach(function(topic) {
        if(persona.topics.includes(topic)) topicMatch++;
      });
      topicMatch = topicMatch / Math.min(analysisResult.topics.length, 3);
    }

    const userEmotionSum = Object.values(userEmotionVec).reduce(function(a, b) { return a + b; }, 0);
    const personaEmotionSum = Object.values(personaEmotionVec).reduce(function(a, b) { return a + b; }, 0);
    const complementarity = userEmotionSum > 0 ? 1 - Math.abs(userEmotionSum - personaEmotionSum) / 200 : 0.5;

    const randomFactor = Math.random() * 0.15 + 0.05;

    const totalScore = emotionSim * 0.35 + topicMatch * 0.30 + complementarity * 0.25 + randomFactor;

    if(totalScore > bestScore) {
      bestScore = totalScore;
      bestMatch = persona;
    }
  });

  const resultScore = Math.round(bestScore * 100);

  return {
    persona: bestMatch,
    score: resultScore,
    emotionSimilarity: Math.round(cosineSimilarity(analysisResult.emotions, Object.fromEntries(Object.entries(bestMatch.emotionProfile).map(function(e) { return [e[0], Math.round(e[1] * 100)]; }))) * 100),
    topicMatch: Math.round((analysisResult.topics.filter(function(t) { return bestMatch.topics.includes(t); }).length / Math.min(analysisResult.topics.length, 3)) * 100) || 50,
    complementarity: Math.round(50 + Math.random() * 30)
  };
}

function findSimilarUsers(analysisResult, excludeId) {
  const results = [];
  userPersonas.forEach(function(persona) {
    if(persona.id === excludeId) return;
    const matchResult = matchPersona(analysisResult);
    results.push({
      persona: persona,
      matchResult: matchResult
    });
  });
  return results.sort(function(a, b) { return b.matchResult.score - a.matchResult.score; }).slice(0, 8);
}

app.get('/api/health', function(req, res) {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

app.post('/api/ai/proxy', function(req, res) {
  const { endpoint, apiKey, body } = req.body;

  if (!endpoint || !apiKey || !body) {
    return res.status(400).json({ error: '缺少必要参数' });
  }

  try {
    const url = new URL(endpoint);
    const isHttps = url.protocol === 'https:';
    const requestModule = isHttps ? https : http;

    const options = {
      hostname: url.hostname,
      port: url.port || (isHttps ? 443 : 80),
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + apiKey
      }
    };

    const proxyReq = requestModule.request(options, function(proxyRes) {
      res.status(proxyRes.statusCode);

      Object.keys(proxyRes.headers).forEach(function(key) {
        if (key.toLowerCase() !== 'content-length') {
          res.setHeader(key, proxyRes.headers[key]);
        }
      });

      proxyRes.pipe(res);
    });

    proxyReq.on('error', function(err) {
      res.status(500).json({ error: '代理请求失败: ' + err.message });
    });

    proxyReq.write(JSON.stringify(body));
    proxyReq.end();

  } catch (err) {
    res.status(500).json({ error: '代理错误: ' + err.message });
  }
});

app.post('/api/analyze', function(req, res) {
  const { text } = req.body;
  if (!text) {
    return res.status(400).json({ error: '请输入文本内容' });
  }
  const result = analyzeText(text);
  res.json(result);
});

app.post('/api/match', function(req, res) {
  const { analysis } = req.body;
  if (!analysis) {
    return res.status(400).json({ error: '缺少分析结果' });
  }
  const result = matchPersona(analysis);
  res.json(result);
});

app.get('/api/personas', function(req, res) {
  res.json(userPersonas);
});

app.get('/api/persona/:id', function(req, res) {
  const id = parseInt(req.params.id);
  const persona = userPersonas.find(function(p) { return p.id === id; });
  if (!persona) {
    return res.status(404).json({ error: '未找到该角色' });
  }
  res.json(persona);
});

app.post('/api/letters', function(req, res) {
  const { personaId, content } = req.body;
  if (!personaId || !content) {
    return res.status(400).json({ error: '缺少必要参数' });
  }
  const letterId = uuidv4();
  const letter = {
    id: letterId,
    personaId: personaId,
    content: content,
    createdAt: new Date().toISOString()
  };
  db.letters.set(letterId, letter);
  res.json({ success: true, letterId: letterId });
});

app.get('/api/letters/:personaId', function(req, res) {
  const personaId = parseInt(req.params.personaId);
  const letters = [];
  db.letters.forEach(function(letter) {
    if (letter.personaId === personaId) {
      letters.push(letter);
    }
  });
  res.json(letters);
});

app.post('/api/user/heartbeat', function(req, res) {
  const { userId } = req.body;
  if (userId) {
    db.onlineUsers.add(userId);
  }
  res.json({ online: db.onlineUsers.size });
});

app.post('/api/user/offline', function(req, res) {
  const { userId } = req.body;
  if (userId) {
    db.onlineUsers.delete(userId);
  }
  res.json({ success: true });
});

app.get('/api/stats', function(req, res) {
  res.json({
    totalUsers: userPersonas.length,
    onlineUsers: db.onlineUsers.size,
    totalLetters: db.letters.size
  });
});

module.exports = app;

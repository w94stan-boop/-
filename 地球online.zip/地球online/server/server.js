require('dotenv').config();
const path = require('path');
const express = require('express');
const app = require('./app');

const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, '..')));

app.listen(PORT, function() {
  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log('  ║     星轨共鸣 · 后端服务已启动        ║');
  console.log('  ╠══════════════════════════════════════╣');
  console.log('  ║  地址: http://localhost:' + PORT + '           ║');
  console.log('  ║  首页: http://localhost:' + PORT + '/index.html ║');
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
});

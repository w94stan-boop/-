const app = require('../server/app');

module.exports = function(req, res) {
  app(req, res);
};
